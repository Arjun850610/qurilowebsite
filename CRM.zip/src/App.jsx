import CRM from './pages/CRM'

const App = () => {
  return (
    <div className='w-full'>
      <CRM />
    </div>
  )
}

export default App  