/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      fontFamily: {
        'sans': ['Nunito Sans', 'ui-sans-serif', 'system-ui'],
      },
      colors: {
        primary: {
          100: "#0D184B"
        },
        secondary: {
          100: "#CC3D5C"
        },
        lightColor: {
          100: "#F9AB6F"
        },
        banner: {
          100: "#1f2937"
        },
        bgColor: {
          100: "#558BDC"
        },
        'networkbg':'#F2F2F2',
          'first':'#0A142A',
          'second':"#D6DFF9",
          'third':"#E1DCF3",
          'fourth':"#F9EBDD",
          "blue":"#558BDC",
          "creme":"#F9EBDD",
          "carasoul":"#0D184B"
      },
      animation: {
        'spin-slow': 'spin 20s linear infinite',
      },
    },
  },
  plugins: [],
}